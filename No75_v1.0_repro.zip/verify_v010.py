"""Exact finite bases for the all-dimension proof. Python 3.10+, stdlib."""
from itertools import product, combinations
from collections import Counter, deque
from pathlib import Path
import hashlib

def require(ok, msg):
    if not ok: raise ValueError(msg)

F=[0,1]
for _ in range(22): F.append(F[-1]+F[-2])

def fibwords(n):
    words=[0]
    for i in range(n):
        words += [x|(1<<i) for x in words if i==0 or not x&(1<<(i-1))]
    return words

for d in (4,5):
    count=0; minimum=None; largest_n=0; min_exclusion=None
    all_bits=list(product((0,1), repeat=d))
    for L,R in product(range(2),repeat=2):
        for gaps in product((1,2,3),repeat=d-1):
            I=[L]
            for g in gaps: I.append(I[-1]+g)
            n=I[-1]+1+R
            largest_n=max(largest_n,n)
            # Formula implementation: each factor is a Fibonacci number.
            table={}
            for a in all_bits:
                z=F[L+2-a[0]]*F[R+2-a[-1]]
                for j,g in enumerate(gaps): z*=F[g+1-a[j]-a[j+1]]
                table[a]=z
            # Independent implementation: explicit enumeration of every legal word,
            # including those whose projections violate the requested pattern.
            literal=Counter(tuple((x>>i)&1 for i in I) for x in range(1<<n) if not x&(x<<1))
            require(all(table[a]==literal[a] for a in all_bits),('projection histogram',L,R,gaps))
            require(sum(table.values())==F[n+2],('vertex total',n))
            # Independent center feasibility check via actual bit flips, with
            # all non-designated coordinates zero (sufficient and necessary).
            for v in all_bits:
                feasible=all(g!=1 or (v[j]==v[j+1]==0) for j,g in enumerate(gaps))
                center=sum(b<<i for b,i in zip(v,I))
                legal=lambda x:not x&(x<<1)
                actual=legal(center) and all(legal(center^(1<<i)) for i in I)
                require(feasible==actual,('star feasibility',I,v))
                if not feasible:continue
                D=sum(z for a,z in table.items() if 2<=sum(b!=c for b,c in zip(a,v))<=d-2)
                margin=5*F[n]-2*(F[n+2]-D) if d==4 else D-F[n-1]
                require(margin>0,('base margin',n,I,v,margin))
                minimum=margin if minimum is None else min(minimum,margin)
                count+=1
    require((count,minimum,largest_n)==({4:(748,5,12),5:(3412,4,15)}[d]),('summary',d,count,minimum,largest_n))
    print(f'PASS d={d} bases={count} min_margin={minimum} largest_n={largest_n} exact_histograms_vs_literal_words')

# Small equality cases: graph adjacency + BFS, enumerate ALL shortest paths,
# then every selected-edge subset. No coordinate criterion used in the check.
for n in range(2,5):
    V=[x for x in range(1<<n) if not x&(x<<1)]
    E=[(x,y) for x,y in combinations(V,2) if (x^y).bit_count()==1]
    A={x:[] for x in V}
    for j,(x,y) in enumerate(E):A[x].append((y,j));A[y].append((x,j))
    triples=set()
    for s in V:
        dist={s:0};q=deque([s])
        while q:
            x=q.popleft()
            for y,_ in A[x]:
                if y not in dist:dist[y]=dist[x]+1;q.append(y)
        def dfs(x,used):
            if len(used)>=3:
                triples.update(sum(1<<j for j in t) for t in combinations(used,3))
            for y,j in A[x]:
                if dist[y]==dist[x]+1:dfs(y,used+[j])
        dfs(s,[])
    opt=-1; winners=[]
    for mask in range(1<<len(E)):
        if any(mask&t==t for t in triples):continue
        size=mask.bit_count()
        if size>opt:opt=size;winners=[mask]
        elif size==opt:winners.append(mask)
    target=sum(1<<j for j,(x,y) in enumerate(E) if x^y in (1,1<<(n-1)))
    require(opt==2*F[n] and winners==[target],('small equality',n,opt,winners,target))
    print(f'PASS n={n} exhaustive_BFS optimum={opt} unique_boundary_union=True')
print('FINAL PASS / EXACT FINITE BASES AND SMALL EQUALITY CASES / ANALYTIC PROOF AUDITED / v1.0')
